import requests

class TeslaAPIClient:
    def __init__(self, auth_token, vehicle_id):
        self.auth_token = auth_token
        self.vehicle_id = vehicle_id

    def get_speed_and_location(self):
        url = f"https://owner-api.teslamotors.com/api/1/vehicles/{self.vehicle_id}/data_request/drive_state"
        headers = {"Authorization": f"Bearer {self.auth_token}"}
        response = requests.get(url, headers=headers)
        data = response.json()
        speed = data['response']['speed']  # mph
        lat = data['response']['latitude']
        lon = data['response']['longitude']
        return speed, lat, lon

    def is_on_road(self, lat, lon):
        # Placeholder for real road validation
        return True
