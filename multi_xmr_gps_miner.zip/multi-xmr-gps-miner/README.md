# Multi-Platform GPS-Triggered XMRig Mining System

This project provides a modular mining controller framework that supports:

- Mobile devices (Android/iOS) using GPS speed and road validation
- Tesla vehicle integration using Tesla's REST API
- Other smart vehicles (Ford, Chevy) integration via manufacturer APIs

## Folder Structure

- core/: Shared mining controller and GPS speed/road validation logic
- mobile_app/: Mobile app skeletons for Android and iOS
- tesla_extension/: Tesla API client integration
- ford_extension/: Ford API client stub
- chevy_extension/: Chevy API client stub

## How to Use

- Implement or connect your platform-specific APIs
- Run the mining controller for the selected platform
- Configure XMRig or your miner accordingly

## Notes

- Real road validation should be implemented offline or via trusted APIs
- Tesla/Ford/Chevy API keys and tokens must be obtained separately
- Mining should be throttled to avoid overheating and battery drain

