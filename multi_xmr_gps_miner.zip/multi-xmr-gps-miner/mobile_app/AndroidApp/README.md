# Android App for GPS-Triggered XMRig Mining

- Uses Android location services to track speed and location
- Starts XMRig mobile mining when speed > 10 mph on a verified road
- Stops mining when speed drops or off-road detected

## To Do:
- Implement GPS tracking
- Integrate XMRig mobile binary
- Offline road validation with OSM data
