class MiningController:
    def __init__(self, platform):
        self.platform = platform
        self.mining_active = False

    def check_and_mine(self):
        speed, lat, lon = self.platform.get_speed_and_location()
        if self.platform.is_on_road(lat, lon) and speed >= 10:
            if not self.mining_active:
                self.start_mining()
        else:
            if self.mining_active:
                self.stop_mining()

    def start_mining(self):
        print("Mining started")
        # launch XMRig process (platform-specific)
        self.mining_active = True

    def stop_mining(self):
        print("Mining stopped")
        # stop XMRig process (platform-specific)
        self.mining_active = False
