def is_on_road(lat, lon):
    # TODO: Implement offline road check with OSM or Google Roads API
    # Placeholder: accept all locations for now
    return True
