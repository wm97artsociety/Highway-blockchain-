def is_speed_valid(speed_mph):
    return speed_mph >= 5

def is_mining_speed(speed_mph):
    return speed_mph >= 10
