class FordAPIClient:
    def __init__(self, api_key):
        self.api_key = api_key

    def get_speed_and_location(self):
        # TODO: Implement Ford Connected Services API call
        # Return dummy values for now
        speed = 0
        lat = 0
        lon = 0
        return speed, lat, lon

    def is_on_road(self, lat, lon):
        # TODO: Implement road validation
        return True
